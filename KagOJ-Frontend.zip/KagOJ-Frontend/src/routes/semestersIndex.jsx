export default function SemestersIndex() {
    return (
      <p id="zero-state">
        KagOJ Semesters
        <br />
        Check out{" "}
        <a href="https://reactrouter.com">
          the docs at reactrouter.com
        </a>
        .
      </p>
    );
  }